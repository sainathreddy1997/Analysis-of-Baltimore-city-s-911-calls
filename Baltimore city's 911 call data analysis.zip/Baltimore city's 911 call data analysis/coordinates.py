def coordinates(zip_code):
    if zip_code == 21217.0:
        return 39.2847, -76.6205
    if zip_code == 21215.0:
        return 39.346, -76.681
    if zip_code == 21218.0:
        return 39.325, -76.605
    if zip_code == 21223.0:
        return 39.289, -76.651
    if zip_code == 21202.0:
        return 39.296, -76.609
    if zip_code == 21224.0:
        return 39.284, -76.560
    if zip_code == 21213.0:
        return 39.313, -76.584
    if zip_code == 21230.0:
        return 39.271, -76.637
    if zip_code == 21229.0:
        return 39.285, -76.690
    if zip_code == 21201.0:
        return 39.295, -76.625
    if zip_code == 21216.0:
        return 39.308, -76.677
    if zip_code == 21206.0:
        return 39.342, -76.531
    if zip_code == 21205.0:
        return 39.305, -76.568
    if zip_code == 21225.0:
        return 39.222, -76.618
    if zip_code == 21212.0:
        return 39.359, -76.613
    if zip_code == 21231.0:
        return 39.290, -76.594
    if zip_code == 21239.0:
        return 39.359, -76.591
    if zip_code == 21211.0:
        return 39.330, -76.637
    if zip_code == 21214.0:
        return 39.354, -76.561
    if zip_code == 21207.0:
        return 39.333, -76.731
    else:
        return 39.2847,-76.6205
